let modal = document.getElementById('contact-modal'),
    openModal = document.getElementById('modal-open'),
    closeModal = document.querySelector('.close-modal');

openModal.addEventListener('click', function() {
    modal.style.display = 'block';
})

closeModal.addEventListener('click', function() {
    modal.style.display = 'none';
})

closeModal.addEventListener('click', function(e) {
    if(e.target == modal) {
        modal.style.display = 'none';
    }
})

let modal1 = document.getElementById('contact-modal1'),
    openModal1 = document.getElementById('open-edit'),
    closeModal1 = document.querySelector('.close-modal1');

openModal1.addEventListener('click', function() {
    modal1.style.display = 'block';
})

closeModal1.addEventListener('click', function() {
    modal1.style.display = 'none';
})

closeModal1.addEventListener('click', function(ee) {
    if(ee.target == modal1) {
        modal1.style.display = 'none';
    }
})

// profile img
// const proPic = document.quertySelector('.profile-pic');
// const img = document.querySelector('#photo');
// const file = document.querySelector('#file');
// const uploadBtn = document.querySelector('#uploadBtn');

//choose file upload
// file.addEventListener('change', function(){
//     const choosedFile = this.files[0];
//     if (choosedFile) {
//         const reader = new FileReader(); //FileReader is a predefined fuction of JS
//         reader.addEventListener('load', function(){
//             img.setAttribute('src', reader.result);
//         });

//         reader.readAsDataURL(choosedFile);
//     }
// });