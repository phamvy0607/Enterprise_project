let modal = document.getElementById('contact-modal'),
    openModal = document.getElementById('open'),
    closeModal = document.querySelector('.close-modal');

openModal.addEventListener('click', function() {
    modal.style.display = 'block';
})

closeModal.addEventListener('click', function() {
    modal.style.display = 'none';
})

closeModal.addEventListener('click', function(e) {
    if(e.target == modal) {
        modal.style.display = 'none';
    }
})

// profile img
// const proPic = document.quertySelector('.profile-pic');
// const img = document.querySelector('#photo');
// const file = document.querySelector('#file');
// const uploadBtn = document.querySelector('#uploadBtn');

//choose file upload
// file.addEventListener('change', function(){
//     const choosedFile = this.files[0];
//     if (choosedFile) {
//         const reader = new FileReader(); //FileReader is a predefined fuction of JS
//         reader.addEventListener('load', function(){
//             img.setAttribute('src', reader.result);
//         });

//         reader.readAsDataURL(choosedFile);
//     }
// });