const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
    type: 'polarArea',
    data: {
        labels: ['Like', 'Dislike', 'Comment', 'View'],
        datasets: [{
            label: '# of Votes',
            data: [2073, 873, 1508, 5489],
            backgroundColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
            ],
        }]
    },
    options: {
        responsive: true, 
    }
});

const counting = document.getElementById('count').getContext('2d');
const count = new Chart(counting, {
    type: 'bar',
    data: {
        labels: ['Like', 'Dislike', 'Comment', 'View'],
        datasets: [{
            label: '# Amount',
            data: [2073, 873, 1508, 5489],
            backgroundColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
            ]
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true,
            }
        }
    }
});


   