const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
    type: 'polarArea',
    data: {
        labels: ['Percentage of ideas by Academic Department', 'Percentage of ideas by Support Department'],
        datasets: [{
            label: '# Percentage of ideas by each Department.',
            data: [62, 38],
            backgroundColor: [
                '#3E8E7E',
                '#FABB51',
            ],
        }]
    },
    options: {
        responsive: true, 
    }
});

const counting = document.getElementById('count').getContext('2d');
const count = new Chart(counting, {
    type: 'bar',
    data: {
        labels: ['Number of ideas made by Academic', 'Number of ideas made by Support', 'Number of contributors within Academic', 'Number of contributors within Support'],
        datasets: [{
            label: '#chart',
            data: [40, 17, 42, 28],
            backgroundColor: [
                '#3E8E7E',
                '#FABB51',
                '#3E8E7E',
                '#FABB51',
            ]
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true,
            }
        }
    }
});


   